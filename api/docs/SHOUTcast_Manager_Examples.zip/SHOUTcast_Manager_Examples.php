<?php
/*
 * @author: Scottish Borders Design
 * @script: SBD SHOUTcast Manager
 * @function: Example API
 * @website: http://scottishbordersdesign.co.uk/
 */

$hostURL = "https://shoutcast-server.hostserver.com/public/api/";
$apikey = "O1L0-GP74-6YR";
$port = "9000";

function doCall($type, $key, $port, $call, $method="POST", $postData=null){
	global $hostURL;
	$method = ($method == 'POST') ? true : false;
	if (!$postData) {
		$postData = array();
	}
	$url = $hostURL . $type . '/' . $key . '/' . $port . '/' . $call . '/';

	$ch = curl_init();
	curl_setopt_array($ch, array(
	    CURLOPT_URL => $url ,
	    CURLOPT_RETURNTRANSFER => true,
	    CURLOPT_POST => $method,
	    CURLOPT_POSTFIELDS => $postData,
	    CURLOPT_FOLLOWLOCATION => true
	));

	$output = curl_exec($ch);
	echo $output;
}

/*
* Example Calls to SHOUTcast Server
*/
	// GET call to start server
	echo doCall("server", $apikey, $port, "start");

	// GET call to start AutoDJ
	echo doCall("autodj", $apikey, $port, "start");

	//POST call to Change Broadcast Password
	$postdata = array(
		"settings" => "1",
		"broadcast_password" => "ChAnGe_Me!"
	);
	echo doCall("server", $apikey, $port, "settings", "POST", $postdata);
// © Scottish Borders Design 2016